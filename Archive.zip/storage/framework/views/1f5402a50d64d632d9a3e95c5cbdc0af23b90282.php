<?php if(isset($entities)): ?>
<div class="card shadow border-0 h-100">
  <div class="card-body">
    <h3>Results</h3>
    <ul class="list-group list-group-flush">
      <?php $__currentLoopData = $entities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="list-group-item">
          <a href="/entity/<?php echo $entity['id'];?>">
          <?php echo $entity['name']; ?>
          </a>
        </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
</div>
<?php endif; ?>
<?php /**PATH /Applications/MAMP/htdocs/rens/resources/views/results.blade.php ENDPATH**/ ?>