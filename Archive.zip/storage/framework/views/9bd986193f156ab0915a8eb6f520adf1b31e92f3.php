<div class="card shadow border-0 h-100">
  <div class="card-body">
    <h3>Options</h3>
    <ul class="list-group list-group-flush">
      <li class="list-group-item"><a href="#">Search</a></li>
      <li class="list-group-item"><a href="#">Advanced Search</a></li>
    </ul>
  </div>
</div>
<?php /**PATH /Applications/MAMP/htdocs/rens/resources/views/options.blade.php ENDPATH**/ ?>