<div class="row" style="text-align: center;">
  <div class="col-md mb-4">
    <h1>Global Look</h1>
  </div>
</div>
<?php /**PATH /Applications/MAMP/htdocs/rens/resources/views/partial/title.blade.php ENDPATH**/ ?>