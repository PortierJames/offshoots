<div class="card shadow border-0 h-100">
  <div class="card-body">
    <h3>Search</h3>
    <form action="/rens/public/search" method="POST" role="search">
      <?php echo e(csrf_field()); ?>

      <div class="input-group">
      <input type="text" class="form-control" name="q" placeholder="Search entities">
        <span class="input-group-btn">
          <button type="submit" class="btn btn-primary">Search</button>
        </span>
      </div>
    </form>
  </div>
</div>
<?php /**PATH /Applications/MAMP/htdocs/rens/resources/views/search.blade.php ENDPATH**/ ?>