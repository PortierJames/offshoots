@extends('layouts.base')

@section('search')
  @include('partial/profile')
@endsection
