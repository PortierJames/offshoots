<div class="col-md-4 mb-4">
<div class="card shadow border-0 h-100">
  <div class="card-body">
    <h3>Options</h3>
    <ul class="list-group list-group-flush">
      <li class="list-group-item"><a href="#">Search</a></li>
      <li class="list-group-item"><a href="#">Advanced Search</a></li>
    </ul>
  </div>
</div>
</div>
