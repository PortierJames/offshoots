<div class="row" style="text-align: center;">
  <div class="col-md mb-4">
    <h1>Global Look</h1>
  </div>
</div>
